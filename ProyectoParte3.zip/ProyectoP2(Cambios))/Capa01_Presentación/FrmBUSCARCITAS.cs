﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmBUSCARCITAS : Form
    {
        public event EventHandler Aceptar2;
        int global_id_Cita;
        public FrmBUSCARCITAS()
        {
            InitializeComponent();
        }





        public void CargarListaCitas(string condicion = "")
        {
            BLCita2 logicaCita = new BLCita2(Configuracion.getConnectionString);
            List<EntidadCita> listaCitas;

            try
            {
                // Llamar al método de la capa lógica para obtener la lista de citas
                listaCitas = logicaCita.LlamarListaCitas(condicion);

                // Comprobar si la lista de citas contiene registros
                if (listaCitas.Count > 0)
                {
                    // Asignar la lista como origen de datos del DataGridView
                    grdCitas.DataSource = listaCitas;
                }
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje de error en caso de excepción
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//FIN



        private void FrmBUSCARCITAS_Load(object sender, EventArgs e)
        {
            try   //cargamos la lista de pacientes al cargar el formulario y se muestra en el datagridview
            {
                CargarListaCitas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtID_Cita.Text))
                {
                    // Verificamos que el campo de ID_Cita contenga un número válido
                    if (int.TryParse(txtID_Cita.Text.Trim(), out int idCita))
                    {
                        // Usamos el ID_Cita para buscar la cita
                        //condicion = string.Format("ID_Cita = {0}", idCita);
                        condicion = string.Format("ID_Cita LIKE '%{0}%'", txtID_Cita.Text.Trim());

                    }
                    else
                    {
                        MessageBox.Show("El ID de la cita debe ser un número válido", "Atención",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtID_Cita.Focus();
                        return; // Salimos del método sin ejecutar la búsqueda
                    }
                }
                else
                {
                    MessageBox.Show("Debe ingresar el ID de la cita a buscar", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtID_Cita.Focus();
                    return; // Salimos del método sin ejecutar la búsqueda
                }

                CargarListaCitas(condicion);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }



        private void seleccionar()
        {
            /*if (grdListaPacientes.SelectedRows.Count > 0)
            {
                global_id_paciente = (int)grdListaPacientes.SelectedRows[0].Cells[0].Value;
                Aceptar(global_id_paciente, null);
                Close();
            }
            */
            string nombreColumna = "ID_CITA"; //directamente se accede al índice de la columna con el nombre "ID_CITA" 
            int indiceColumna = grdCitas.Columns[nombreColumna].Index;
            DataGridViewCell cell = grdCitas.SelectedRows[0].Cells[indiceColumna];
            if (cell != null && cell.Value != null)
            {

                global_id_Cita = (int)cell.Value;
                Aceptar2(global_id_Cita, null);
                Close();
            }




        }



        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();

        }


        /*
        private void grdListaPacientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            seleccionar();
        }
        */


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar2(-1, null);
            Close();
        }



        private void grdCitas_DoubleClick(object sender, EventArgs e)
        {

            int id = 0;
            try
            {
                id = (int)grdCitas.SelectedRows[0].Cells[0].Value;
                CargarListaCitas(id.ToString());



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //seleccionar();
        }


    }
}
