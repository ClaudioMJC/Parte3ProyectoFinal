﻿namespace Capa01_Presentación
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            menuStrip1 = new System.Windows.Forms.MenuStrip();
            registrarPacienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            registrarPacientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            agendarCitaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            historialMedicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            gestiónDeUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            horarioDeTrabajadoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { registrarPacienteToolStripMenuItem, historialMedicoToolStripMenuItem, gestiónDeUsuariosToolStripMenuItem, horarioDeTrabajadoresToolStripMenuItem });
            menuStrip1.Location = new System.Drawing.Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new System.Drawing.Size(981, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // registrarPacienteToolStripMenuItem
            // 
            registrarPacienteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { registrarPacientesToolStripMenuItem, agendarCitaToolStripMenuItem1 });
            registrarPacienteToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("registrarPacienteToolStripMenuItem.Image");
            registrarPacienteToolStripMenuItem.Name = "registrarPacienteToolStripMenuItem";
            registrarPacienteToolStripMenuItem.Size = new System.Drawing.Size(124, 29);
            registrarPacienteToolStripMenuItem.Text = "Pacientes";
            // 
            // registrarPacientesToolStripMenuItem
            // 
            registrarPacientesToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("registrarPacientesToolStripMenuItem.Image");
            registrarPacientesToolStripMenuItem.Name = "registrarPacientesToolStripMenuItem";
            registrarPacientesToolStripMenuItem.Size = new System.Drawing.Size(260, 34);
            registrarPacientesToolStripMenuItem.Text = "Registrar Pacientes";
            registrarPacientesToolStripMenuItem.Click += registrarPacienteToolStripMenuItem_Click;
            // 
            // agendarCitaToolStripMenuItem1
            // 
            agendarCitaToolStripMenuItem1.Image = (System.Drawing.Image)resources.GetObject("agendarCitaToolStripMenuItem1.Image");
            agendarCitaToolStripMenuItem1.Name = "agendarCitaToolStripMenuItem1";
            agendarCitaToolStripMenuItem1.Size = new System.Drawing.Size(260, 34);
            agendarCitaToolStripMenuItem1.Text = "Agendar Cita";
            agendarCitaToolStripMenuItem1.Click += agendarCitaToolStripMenuItem1_Click;
            // 
            // historialMedicoToolStripMenuItem
            // 
            historialMedicoToolStripMenuItem.Name = "historialMedicoToolStripMenuItem";
            historialMedicoToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            historialMedicoToolStripMenuItem.Text = "Historial Medico";
            historialMedicoToolStripMenuItem.Click += historialMedicoToolStripMenuItem_Click;
            // 
            // gestiónDeUsuariosToolStripMenuItem
            // 
            gestiónDeUsuariosToolStripMenuItem.Name = "gestiónDeUsuariosToolStripMenuItem";
            gestiónDeUsuariosToolStripMenuItem.Size = new System.Drawing.Size(186, 29);
            gestiónDeUsuariosToolStripMenuItem.Text = "Gestión de Usuarios";
            gestiónDeUsuariosToolStripMenuItem.Click += gestiónDeUsuariosToolStripMenuItem_Click;
            // 
            // horarioDeTrabajadoresToolStripMenuItem
            // 
            horarioDeTrabajadoresToolStripMenuItem.Name = "horarioDeTrabajadoresToolStripMenuItem";
            horarioDeTrabajadoresToolStripMenuItem.Size = new System.Drawing.Size(218, 29);
            horarioDeTrabajadoresToolStripMenuItem.Text = "Horario de Trabajadores";
            horarioDeTrabajadoresToolStripMenuItem.Click += horarioDeTrabajadoresToolStripMenuItem_Click;
            // 
            // FrmMenu
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(981, 450);
            Controls.Add(menuStrip1);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "FrmMenu";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Menú";
            WindowState = System.Windows.Forms.FormWindowState.Maximized;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem registrarPacienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historialMedicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestiónDeUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horarioDeTrabajadoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarPacientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agendarCitaToolStripMenuItem1;
    }
}