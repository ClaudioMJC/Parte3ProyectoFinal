﻿namespace Capa01_Presentación
{
    partial class FrmBuscarHorario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscarHorario));
            label2 = new System.Windows.Forms.Label();
            txtID_Horario = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnAceptar = new System.Windows.Forms.Button();
            btnCancelar = new System.Windows.Forms.Button();
            grdHorarios = new System.Windows.Forms.DataGridView();
            ID_HORARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_USUARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DIASTRABAJADOS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            HORA_INICIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            HORA_FIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)grdHorarios).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(31, 54);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(168, 25);
            label2.TabIndex = 81;
            label2.Text = "Nombre de Usuario";
            // 
            // txtID_Horario
            // 
            txtID_Horario.Location = new System.Drawing.Point(216, 54);
            txtID_Horario.Name = "txtID_Horario";
            txtID_Horario.Size = new System.Drawing.Size(416, 31);
            txtID_Horario.TabIndex = 80;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnBuscar.Location = new System.Drawing.Point(671, 43);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(98, 52);
            btnBuscar.TabIndex = 79;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnAceptar.Location = new System.Drawing.Point(438, 335);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(148, 72);
            btnAceptar.TabIndex = 78;
            btnAceptar.Text = "&Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnCancelar.Location = new System.Drawing.Point(623, 335);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(146, 72);
            btnCancelar.TabIndex = 77;
            btnCancelar.Text = "&Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // grdHorarios
            // 
            grdHorarios.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdHorarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdHorarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_HORARIO, ID_USUARIO, DIASTRABAJADOS, HORA_INICIO, HORA_FIN });
            grdHorarios.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdHorarios.Location = new System.Drawing.Point(9, 141);
            grdHorarios.Name = "grdHorarios";
            grdHorarios.RowHeadersWidth = 62;
            grdHorarios.RowTemplate.Height = 33;
            grdHorarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdHorarios.Size = new System.Drawing.Size(760, 169);
            grdHorarios.TabIndex = 82;
            grdHorarios.DoubleClick += grdHorarios_DoubleClick;
            // 
            // ID_HORARIO
            // 
            ID_HORARIO.DataPropertyName = "ID_HORARIO";
            ID_HORARIO.HeaderText = "ID_HORARIO";
            ID_HORARIO.MinimumWidth = 8;
            ID_HORARIO.Name = "ID_HORARIO";
            ID_HORARIO.Width = 150;
            // 
            // ID_USUARIO
            // 
            ID_USUARIO.DataPropertyName = "ID_USUARIO";
            ID_USUARIO.HeaderText = "ID_USUARIO";
            ID_USUARIO.MinimumWidth = 8;
            ID_USUARIO.Name = "ID_USUARIO";
            ID_USUARIO.Width = 150;
            // 
            // DIASTRABAJADOS
            // 
            DIASTRABAJADOS.DataPropertyName = "DIASTRABAJADOS";
            DIASTRABAJADOS.HeaderText = "Dias Trabajados";
            DIASTRABAJADOS.MinimumWidth = 8;
            DIASTRABAJADOS.Name = "DIASTRABAJADOS";
            DIASTRABAJADOS.Width = 150;
            // 
            // HORA_INICIO
            // 
            HORA_INICIO.DataPropertyName = "HORAINICIO";
            HORA_INICIO.HeaderText = "HORA_INICIO";
            HORA_INICIO.MinimumWidth = 8;
            HORA_INICIO.Name = "HORA_INICIO";
            HORA_INICIO.Width = 150;
            // 
            // HORA_FIN
            // 
            HORA_FIN.DataPropertyName = "HORAFIN";
            HORA_FIN.HeaderText = "HORA_FIN";
            HORA_FIN.MinimumWidth = 8;
            HORA_FIN.Name = "HORA_FIN";
            HORA_FIN.Width = 150;
            // 
            // FrmBuscarHorario
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(grdHorarios);
            Controls.Add(label2);
            Controls.Add(txtID_Horario);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(btnCancelar);
            Name = "FrmBuscarHorario";
            Text = "FrmBuscarHorario";
            Load += FrmBuscarHorario_Load;
            ((System.ComponentModel.ISupportInitialize)grdHorarios).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtID_Horario;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.DataGridView grdHorarios;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_HORARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_USUARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIASTRABAJADOS;
        private System.Windows.Forms.DataGridViewTextBoxColumn HORA_INICIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn HORA_FIN;
    }
}