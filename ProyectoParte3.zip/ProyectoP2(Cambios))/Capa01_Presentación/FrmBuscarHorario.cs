﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmBuscarHorario : Form
    {
        public event EventHandler Aceptar;
        int global_id_Horario;
        public FrmBuscarHorario()
        {
            InitializeComponent();
        }

        public void CargarListaHorarios(string condicion = "")
        {
            BLHorario logicaBuscar = new BLHorario(Configuracion.getConnectionString);
            List<EntidadHorario> listarHorarios;
            try
            {
                listarHorarios = logicaBuscar.LlamarListaHorarios(condicion);
                if (listarHorarios.Count > 0)
                {
                    grdHorarios.DataSource = listarHorarios;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmBuscarHorario_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaHorarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtID_Horario.Text))
                {
                    // Verificamos que el campo de ID_Cita contenga un número válido
                    if (int.TryParse(txtID_Horario.Text.Trim(), out int idHorario))
                    {
                      
                        condicion = string.Format("ID_Horario LIKE '%{0}%'", txtID_Horario.Text.Trim());

                    }
                    else
                    {
                        MessageBox.Show("El ID del horario debe ser un número válido", "Atención",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtID_Horario.Focus();
                        return; // Salimos del método sin ejecutar la búsqueda
                    }
                }
                else
                {
                    MessageBox.Show("Debe ingresar el ID del horario a buscar", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtID_Horario.Focus();
                    return; // Salimos del método sin ejecutar la búsqueda
                }

                CargarListaHorarios(condicion);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }





        private void seleccionar()
        {

            string nombreColumna = "ID_HORARIO"; //directamente se accede al índice de la columna con el nombre "ID_CITA" 
            int indiceColumna = grdHorarios.Columns[nombreColumna].Index;
            DataGridViewCell cell = grdHorarios.SelectedRows[0].Cells[indiceColumna];
            if (cell != null && cell.Value != null)
            {

                global_id_Horario = (int)cell.Value;
                Aceptar(global_id_Horario, null);
                Close();
            }




        }


        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();

        }





        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar(-1, null);
            Close();
        }

        private void grdHorarios_DoubleClick(object sender, EventArgs e)
        {
            int id = 0;
            try
            {
                id = (int)grdHorarios.SelectedRows[0].Cells[0].Value;
                CargarListaHorarios(id.ToString());



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
