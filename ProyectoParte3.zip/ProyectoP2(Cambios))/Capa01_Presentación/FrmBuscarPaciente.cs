﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmBuscarPaciente : Form
    {

        public event EventHandler Aceptar;
        int global_id_paciente;
        public FrmBuscarPaciente()
        {
            InitializeComponent();
        }


        public void CargarListaPacientes(string condicion = "")
        {
            BLPaciente logicaBuscar = new BLPaciente(Configuracion.getConnectionString);
            List<EntidadPaciente> listarPacientes;
            try
            {
                listarPacientes = logicaBuscar.llamarListaPacientes(condicion);
                if (listarPacientes.Count > 0)
                {
                    grdListaPacientes.DataSource = listarPacientes;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmBuscarPaciente_Load(object sender, EventArgs e)
        {
            try   //cargamos el datagridview con los pacientes de la base de datos
            {
                CargarListaPacientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtNombre.Text))
                {
                    //lo que escriba en el txtNombre, el Trim le quita los espacios en blanco
                    condicion = string.Format("Nombre like '%{0}%'", txtNombre.Text.Trim());

                }
                else
                {
                    MessageBox.Show("Debe escribir por lo menos una letra del nombre a buscar", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNombre.Focus();
                }
                CargarListaPacientes(condicion);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void seleccionar()
        {
            /*if (grdListaPacientes.SelectedRows.Count > 0)
            {
                global_id_paciente = (int)grdListaPacientes.SelectedRows[0].Cells[0].Value;
                Aceptar(global_id_paciente, null);
                Close();
            }
            */
            string nombreColumna = "ID_PACIENTE"; //directamente se accede al índice de la columna con el nombre "ID_PACIENTE" 
            int indiceColumna = grdListaPacientes.Columns[nombreColumna].Index;
            DataGridViewCell cell = grdListaPacientes.SelectedRows[0].Cells[indiceColumna];
            if (cell != null && cell.Value != null)
            {

                global_id_paciente = (int)cell.Value;
                Aceptar(global_id_paciente, null);
                Close();
            }




        }




        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();

        }
        /*
        private void grdListaPacientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            seleccionar();
        }
        */
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar(-1, null);
            Close();
        }

        private void grdListaPacientes_DoubleClick(object sender, EventArgs e)
        {

            int id = 0;
            try
            {
                id = (int)grdListaPacientes.SelectedRows[0].Cells[0].Value;
                CargarListaPacientes(id.ToString());



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //seleccionar();
        }
    }
}
