﻿namespace Capa01_Presentación
{
    partial class FrmBuscarUSUARIO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscarUSUARIO));
            label2 = new System.Windows.Forms.Label();
            txtNombre = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnAceptar = new System.Windows.Forms.Button();
            btnCancelar = new System.Windows.Forms.Button();
            grdUsuarios = new System.Windows.Forms.DataGridView();
            ID_USUARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_ROL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            NOMBRE_USUARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            CLAVE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)grdUsuarios).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(30, 69);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(168, 25);
            label2.TabIndex = 76;
            label2.Text = "Nombre de Usuario";
            // 
            // txtNombre
            // 
            txtNombre.Location = new System.Drawing.Point(215, 69);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(416, 31);
            txtNombre.TabIndex = 75;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnBuscar.Location = new System.Drawing.Point(660, 58);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(98, 52);
            btnBuscar.TabIndex = 74;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnAceptar.Location = new System.Drawing.Point(437, 350);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(148, 72);
            btnAceptar.TabIndex = 73;
            btnAceptar.Text = "&Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnCancelar.Location = new System.Drawing.Point(622, 350);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(146, 72);
            btnCancelar.TabIndex = 72;
            btnCancelar.Text = "&Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // grdUsuarios
            // 
            grdUsuarios.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdUsuarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_USUARIO, ID_ROL, NOMBRE_USUARIO, CLAVE });
            grdUsuarios.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdUsuarios.Location = new System.Drawing.Point(30, 152);
            grdUsuarios.Name = "grdUsuarios";
            grdUsuarios.ReadOnly = true;
            grdUsuarios.RowHeadersWidth = 62;
            grdUsuarios.RowTemplate.Height = 33;
            grdUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdUsuarios.Size = new System.Drawing.Size(728, 147);
            grdUsuarios.TabIndex = 77;
            grdUsuarios.Click += grdUsuarios_DoubleClick;
            // 
            // ID_USUARIO
            // 
            ID_USUARIO.DataPropertyName = "ID_USUARIO";
            ID_USUARIO.HeaderText = "ID_USUARIO";
            ID_USUARIO.MinimumWidth = 8;
            ID_USUARIO.Name = "ID_USUARIO";
            ID_USUARIO.ReadOnly = true;
            ID_USUARIO.Width = 150;
            // 
            // ID_ROL
            // 
            ID_ROL.DataPropertyName = "ID_ROL";
            ID_ROL.HeaderText = "ID_ROL";
            ID_ROL.MinimumWidth = 8;
            ID_ROL.Name = "ID_ROL";
            ID_ROL.ReadOnly = true;
            ID_ROL.Visible = false;
            ID_ROL.Width = 150;
            // 
            // NOMBRE_USUARIO
            // 
            NOMBRE_USUARIO.DataPropertyName = "NOMBRE_USUARIO";
            NOMBRE_USUARIO.HeaderText = "NOMBRE_USUARIO";
            NOMBRE_USUARIO.MinimumWidth = 8;
            NOMBRE_USUARIO.Name = "NOMBRE_USUARIO";
            NOMBRE_USUARIO.ReadOnly = true;
            NOMBRE_USUARIO.Width = 150;
            // 
            // CLAVE
            // 
            CLAVE.DataPropertyName = "CLAVE";
            CLAVE.HeaderText = "CONTRASEÑA";
            CLAVE.MinimumWidth = 8;
            CLAVE.Name = "CLAVE";
            CLAVE.ReadOnly = true;
            CLAVE.Width = 150;
            // 
            // FrmBuscarUSUARIO
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(grdUsuarios);
            Controls.Add(label2);
            Controls.Add(txtNombre);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(btnCancelar);
            Name = "FrmBuscarUSUARIO";
            Text = "FrmBuscarUSUARIO";
            Load += FrmBuscarUSUARIO_Load;
            ((System.ComponentModel.ISupportInitialize)grdUsuarios).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.DataGridView grdUsuarios;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_USUARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_ROL;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOMBRE_USUARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLAVE;
    }
}