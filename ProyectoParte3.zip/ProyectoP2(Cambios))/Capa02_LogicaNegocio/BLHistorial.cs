﻿using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Capa02_LogicaNegocio
{
    public class BLHistorial
    {
        private string _cadenaConexion;
        private string _mensaje;

        public string Mensaje
        {
            get => _mensaje;
        }

        public BLHistorial(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }
        /*
        public bool ExisteHistorialMedico(int idHistorial)
        {
            DAHistorial dalHistorial = new DAHistorial(_cadenaConexion);
            return dalHistorial.ExisteHistorialMedico(idHistorial);
        }
        */
        /////////////////////////////////////////////////




        // Método para llamar al método Insertar de la capa de AccesoDatos
        public int LlamarMetodoInsertar(EntidadHistorial_Medico historial)
        {
            int id_historial_medico = 0;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                id_historial_medico = accesoDatos.Insertar(historial);
            }
            catch (Exception)
            {
                throw;
            }
            return id_historial_medico;
        }

        // Método para mostrar la lista de historiales médicos
        public List<EntidadHistorial_Medico> LlamarListaHistoriales(string condicion = "")
        {
            List<EntidadHistorial_Medico> listaHistoriales;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                listaHistoriales = accesoDatos.ListarHistoriales(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaHistoriales;
        }

        // Método para obtener un historial médico por su ID
        public EntidadHistorial_Medico ObtenerHistorial(int id)
        {
            EntidadHistorial_Medico historial;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                historial = accesoDatos.ObtenerHistorial(id);
            }
            catch (Exception)
            {
                throw;
            }
            return historial;
        }

        // Método para eliminar un historial médico
        public int EliminarHistorialMedico(EntidadHistorial_Medico historial)
        {
            int resultado;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarHistorialMedico(historial);
            }
            catch (Exception)
            {
                throw;
            }
            return resultado;
        }

        // Método para modificar un historial médico
        public int Modificar(EntidadHistorial_Medico historial)
        {
            int filasAfectadas = 0;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                filasAfectadas = accesoDatos.Modificar(historial);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;
        }



        public List<int> ObtenerIdPacientes()
        {
            DAHistorial ObtenerID = new DAHistorial(_cadenaConexion);

            return ObtenerID.ObtenerIdPaciente();
        } //fin ObtenerIdPacientes //método enfocado en mostrar la info en el comboBox



        public DataSet ListarHistorial2(string condicion, string orden)
        {
            DataSet DS;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            //se instancia el acceso a los datos
            try
            {
                DS = accesoDatos.ListarHistorial2(condicion, orden);
            }
            catch (Exception)
            {
                throw;
            }

            return DS;
        }// ListarUsuarios





        //combobox INFORMACIÓN DE PACIENTES

        public List<string> ObtenerPacientesH()
        {
            DAHistorial ObtenerP = new DAHistorial(_cadenaConexion);

            return ObtenerP.ObtenerPacientesH();
        }



    }

}  
