﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Text;
using Capa03_AccesoDatos;
using static Capa03_AccesoDatos.DAHorario;
using static CapaEntidades.EntidadHorario;
using static CapaEntidades.EntidadUsuario;
using System.Data;

namespace Capa02_LogicaNegocio
{
    public class BLHorario
    {
        private string _cadenaConexion;
        private string _mensaje;

        public string Mensaje
        {
            get => _mensaje;
        }

        public BLHorario(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public int LlamarMetodoInsertar(EntidadHorario horario)
        {
            int id_horario = 0;
            DAHorario accesoDatos = new DAHorario(_cadenaConexion);
            try
            {
                id_horario = accesoDatos.Insertar(horario);
            }
            catch (Exception)
            {
                throw;
            }
            return id_horario;
        }

        public List<EntidadHorario> LlamarListaHorarios(string condicion = "")
        {
            List<EntidadHorario> listaHorarios;
            DAHorario accesoDatos = new DAHorario(_cadenaConexion);
            try
            {
                listaHorarios = accesoDatos.ListarHorarios(condicion);
            }
            catch (Exception)
            {
                throw;
            }
            return listaHorarios;
        }

        public EntidadHorario ObtenerHorario(int id)
        {
            EntidadHorario horario;
            DAHorario accesoDatos = new DAHorario(_cadenaConexion);
            try
            {
                horario = accesoDatos.ObtenerHorario(id);
            }
            catch (Exception)
            {
                throw;
            }
            return horario;
        }

        public int EliminarHorario(EntidadHorario horario)
        {
            int resultado;
            DAHorario accesoDatos = new DAHorario(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarHorario(horario);
            }
            catch (Exception)
            {
                throw;
            }
            return resultado;
        }

        public int Modificar(EntidadHorario horario)
        {
            int filasAfectadas = 0;
            DAHorario accesoDatos = new DAHorario(_cadenaConexion);
            try
            {
                filasAfectadas = accesoDatos.Modificar(horario);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;
        }


        //comobobox
        public List<UsuarioIdNO> ObtenerIdUsuarioyNombre()
        {
            DAHorario ObtenerIDNom = new DAHorario(_cadenaConexion);

            return ObtenerIDNom.ObtenerIdUsuarioyNombre();
        }


        public List<int> ObtenerIdUsuarios()
        {
            DAHorario ObtenerIDU = new DAHorario(_cadenaConexion);

            return ObtenerIDU.ObtenerIdUsuarios();
        }



        // llama al metodo listar Horarios 2 y trae los datos en un dataSet
        public DataSet ListarHorarios2(string condicion, string orden)
        {
            DataSet DS;
            DAHorario accesoDatos = new DAHorario(_cadenaConexion);
            //se instancia el acceso a los datos
            try
            {
                DS = accesoDatos.ListarHorarios2(condicion, orden);
            }
            catch (Exception)
            {
                throw;
            }

            return DS;
        }// ListarUsuarios




    }

}
