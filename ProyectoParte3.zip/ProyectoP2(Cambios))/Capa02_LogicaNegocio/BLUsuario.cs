﻿using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Capa02_LogicaNegocio
{
    public class BLUsuario
    {
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }
        //constructor de la clase
        public BLUsuario(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }




        ////////LLamanos al método que mostrará el ID de los Roles en el combobox
        public List<int> ObtenerIdRoles()
        {
            DAUsuario ObtenerID = new DAUsuario(_cadenaConexion);

            return ObtenerID.ObtenerIdRoles();
        } //fin ObtenerIdRoles //método enfocado en mostrar la info en el comboBox




        //metodo que se encarga de  llamar al metodo insertar de la capa de AccesoDatos
        public int LlamarMetodoInsertar(EntidadUsuario usuario)
        {
            int id_usuario = 0;
            DAUsuario accesoDatos = new DAUsuario(_cadenaConexion);
            try
            {
                id_usuario = accesoDatos.Insertar(usuario);
            }
            catch (Exception)
            {
                throw;
            }
            return id_usuario;
        }// fin de la clase insertar //HASTA AQUÍ INSERTAR




        public List<EntidadUsuario> LlamarListaUsuarios(string condicion = "")
        {
            List<EntidadUsuario> listaUsuarios;
            DAUsuario accesoDatos = new DAUsuario(_cadenaConexion);
            try
            {
                listaUsuarios = accesoDatos.ListarUsuarios(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaUsuarios;
        }




        public EntidadUsuario ObtenerUsuario(int id)
        {
            EntidadUsuario usuario;
            DAUsuario accesoDatos = new DAUsuario(_cadenaConexion);
            try
            {
                usuario = accesoDatos.ObtenerUsuario(id);
            }
            catch (Exception)
            {
                throw;
            }
            return usuario;
        }



        public int EliminarUsuario(EntidadUsuario usuario)
        {
            int resultado;
            DAUsuario accesoDatos = new DAUsuario(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarUsuario(usuario);
            }
            catch (Exception)
            {
                throw;
            }
            return resultado;
        }



        public int Modificar(EntidadUsuario usuario)
        {
            int filasAfectadas = 0;
            DAUsuario accesoDatos = new DAUsuario(_cadenaConexion);

            try
            {
                filasAfectadas = accesoDatos.Modificar(usuario);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;
        }


        // llama al metodo listar clientes y trae los datos en un dataSet
        public DataSet ListarUsuarios2(string condicion, string orden)
        {
            DataSet DS;
            DAUsuario accesoDatos = new DAUsuario(_cadenaConexion);
            //se instancia el acceso a los datos
            try
            {
                DS = accesoDatos.ListarUsuarios2(condicion, orden);
            }
            catch (Exception)
            {
                throw;
            }

            return DS;
        }// ListarUsuarios


    }
}
