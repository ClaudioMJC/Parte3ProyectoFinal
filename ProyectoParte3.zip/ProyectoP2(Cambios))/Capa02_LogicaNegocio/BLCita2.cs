﻿using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Capa02_LogicaNegocio
{
    public class BLCita2
    {
        private string nombreMedico;
        private string nombreEspecialidad;

        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }
        //constructor de la clase
        public BLCita2(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }



                                   //METODOS PARA LOS COMBOBOX DEL FORM DE REGISTRO DE CITA             
        ////////LLamanos al método que mostrará el ID de los médicos en el combobox
        public List<string> ObtenerIdMedicos()
        {
            DACita2 ObtenerID = new DACita2(_cadenaConexion);

            return ObtenerID.ObtenerIdMedicos();
        } //fin ObtenerIDMedicos //método enfocado en mostrar la info en el comboBox

        //ObtenerIdPacientes()


        ////////LLamanos al método que mostrará el ID de los PACIENTES en el combobox
        public List<string> ObtenerIdPacientes()
        {
            DACita2 ObtenerIDPA = new DACita2(_cadenaConexion);

            return ObtenerIDPA.ObtenerIdPacientes();
        } //fin ObtenerIDPACIENTES //método enfocado en mostrar la info en el comboBox

        //
        //se muestra la info del medico para despúes seleccionar su id
        public List<string> ObtenerMedicosPorEspecialidad()
        {
            DACita2 ObtenerE = new DACita2(_cadenaConexion);

            return ObtenerE.ObtenerEspecialidades();
        } //fin ObtenerMedicosPorEspecialidad //método enfocado en mostrar la info en el comboBox


        //BUSCAMOS EL ID_PAGO ASOCIADO AL PACIENTE
        public List<string> ObtenerIdPagos()
        {
            DACita2 ObtenerIDpG = new DACita2(_cadenaConexion);

            return ObtenerIDpG.ObtenerIdPagos();
        } //fin Obtener IDPAGOS //método enfocado en mostrar la info


        ///////////////////////////FIN DE LO RELACIONADO A LA VISUALIZACIÓN DE DATOS COMBOBOX



        public int LlamarMetodoInsertar(EntidadCita cita)
        {
            int id_cita = 0;
            DACita2 accesoDatos = new DACita2(_cadenaConexion);
            try
            {
                id_cita = accesoDatos.Insertar(cita);
            }
            catch (Exception)
            {
                throw;
            }
            return id_cita;
        }


        ///////////////////////////////////////////////
        public List<EntidadCita> LlamarListaCitas(string condicion = "")
        {
            List<EntidadCita> listaCitas;
            DACita2 accesoDatos = new DACita2(_cadenaConexion);
            try
            {
                listaCitas = accesoDatos.ListarCitas(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaCitas;
        }



        public DataSet ListarCitas2(string condicion, string orden)
        {
            DataSet DS;
            DACita2 accesoDatos = new DACita2(_cadenaConexion);
            //se instancia el acceso a los datos
            try
            {
                DS = accesoDatos.ListarCitas2(condicion, orden);
            }
            catch (Exception)
            {
                throw;
            }

            return DS;
        }// ListarClientes

        ///////////////////////////////////////////////////////
        ///


        public EntidadCita ObtenerCita(int id)
        {
            EntidadCita cita;
            DACita2 accesoDatos = new DACita2(_cadenaConexion);
            try
            {
                cita = accesoDatos.ObtenerCita(id);
            }
            catch (Exception)
            {
                throw;
            }
            return cita;
        }

        //////////////////////////////////////////////////////////////////

        public int EliminarCita(EntidadCita cita)
        {
            int resultado;
            DACita2 accesoDatos = new DACita2(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarCita(cita);
            }
            catch (Exception)
            {
                throw;
            }
            return resultado;
        }

        //////////////////////////////////////////////////////////////////

        public int ModificarCita(EntidadCita cita)
        {
            int filasAfectadas = 0;
            DACita2 accesoDatos = new DACita2(_cadenaConexion);
            try
            {
                filasAfectadas = accesoDatos.Modificar(cita);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;
        }



    }
}
