﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadEnfermero
    {
        private int id_enfermero;
        private int id_rol;
        private string nombre;
        private string apellido;

        public int Id_enfermero { get => id_enfermero; set => id_enfermero = value; }
        public int Id_rol { get => id_rol; set => id_rol = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }

        public EntidadEnfermero(int id_enfermero, int id_rol, string nombre, string apellido)
        {
            this.id_enfermero = id_enfermero;
            this.id_rol = id_rol;
            this.nombre = nombre;
            this.apellido = apellido;
        }
        public EntidadEnfermero()
        {
            id_enfermero = -1; 
            id_rol = -1;
            nombre=string.Empty;
            apellido=string.Empty;
        }
    }
}
