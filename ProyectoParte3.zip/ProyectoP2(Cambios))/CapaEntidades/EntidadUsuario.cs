﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadUsuario
    {
        private int id_usuario;
        private int id_rol;
        private string nombreUsuario;
        private string clave;
        private bool existe;

        public int Id_usuario { get => id_usuario; set => id_usuario = value; }
        public int Id_rol { get => id_rol; set => id_rol = value; }
        public string NombreUsuario { get => nombreUsuario; set => nombreUsuario = value; }
        public string Clave { get => clave; set => clave = value; }
        public bool Existe { get => existe; set => existe = value; }

        public EntidadUsuario(int id_usuario, int id_rol, string nombreUsuario, string contrasena, bool existe)
        {
            this.id_usuario = id_usuario;
            this.id_rol = id_rol;
            this.nombreUsuario = nombreUsuario;
            this.clave = contrasena;
            this.existe = existe;
        }
        public EntidadUsuario() { 
            id_usuario=0; 
            id_rol=0;
            nombreUsuario=string.Empty;
            clave=string.Empty;
            existe=false;
        }

        public class UsuarioIdNO
        {
            public int Id_usuario { get; set; }
            public string NombreUsuario { get; set; }

            public override string ToString()
            {
                return $"{Id_usuario} - {NombreUsuario}";
            }
        }
    }
}
