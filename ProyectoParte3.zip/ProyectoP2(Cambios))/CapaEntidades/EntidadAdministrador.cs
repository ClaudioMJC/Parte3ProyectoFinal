﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CapaEntidades
{
    internal class EntidadAdministrador
    {
        private int id_administrador;
        private int id_usuario;
        private string nombre;
        private string apellido;

        public int Id_administrador { get => id_administrador; set => id_administrador = value; }
        public int Id_usuario { get => id_usuario; set => id_usuario = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }

        public EntidadAdministrador(int id_administrador, int id_usuario, string nombre, string apellido)
        {
            this.id_administrador = id_administrador;
            this.id_usuario = id_usuario;
            this.nombre = nombre;
            this.apellido = apellido;
        }
        public EntidadAdministrador() { }
    }

}
