﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadHorario
    {
        private int id_horario;
        private int id_usuario;
        private string diasTrabajados;
        private TimeSpan horaInicio;
        private TimeSpan horaFin;
        private bool existe;
        public EntidadHorario(int id_horario, int id_usuario, string diasTrabajados, TimeSpan horaInicio, TimeSpan horaFin, bool existe)
        {
            Id_horario = id_horario;
            Id_usuario = id_usuario;
            DiasTrabajados = diasTrabajados;
            HoraInicio = horaInicio;
            HoraFin = horaFin;
            Existe = existe;
            
        }
        public EntidadHorario()
        {
            // Valores predeterminados para los campos
            id_horario = 0;
            id_usuario = 0;
            diasTrabajados = string.Empty;
            horaInicio = TimeSpan.Zero;
            horaFin = TimeSpan.Zero;
            existe = false;
        }

       
        public int Id_horario { get => id_horario; set => id_horario = value; }
        public int Id_usuario { get => id_usuario; set => id_usuario = value; }
        public string DiasTrabajados { get => diasTrabajados; set => diasTrabajados = value; }
        public TimeSpan HoraInicio { get => horaInicio; set => horaInicio = value; }
        public TimeSpan HoraFin { get => horaFin; set => horaFin = value; }
        public bool Existe { get => existe; set => existe = value; }


    }
}
