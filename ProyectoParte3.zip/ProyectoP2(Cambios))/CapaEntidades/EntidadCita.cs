﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadCita
    {
        private int id_cita;
        private DateTime fecha;
        private TimeSpan hora;
        private string descripcion;
        private int id_medico;
        private int id_pago;
        private int id_paciente;
        private string detalle_Medico;
        private bool estado_Pago;
        private bool existe;
        public int Id_cita { get => id_cita; set => id_cita = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public TimeSpan Hora { get => hora; set => hora = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public int Id_medico { get => id_medico; set => id_medico = value; }
        public int Id_pago { get => id_pago; set => id_pago = value; }
        public int Id_paciente { get => id_paciente; set => id_paciente = value; }
        public string Detalle_Medico { get => detalle_Medico; set => detalle_Medico = value; }
        public bool Estado_Pago { get => estado_Pago; set => estado_Pago = value; }
        public bool Existe { get => existe; set => existe = value; }

        public EntidadCita(int id_cita, DateTime fecha, TimeSpan hora, string descripcion, int id_medico, int id_pago, int id_paciente, string detalle_Medico, bool estado_Pago, bool existe)
        {
            this.id_cita = id_cita;
            this.fecha = fecha;
            this.hora = hora;
            this.descripcion = descripcion;
            this.id_medico = id_medico;
            this.id_pago = id_pago;
            this.id_paciente = id_paciente;
            this.detalle_Medico = detalle_Medico;
            this.estado_Pago = false;
            this.existe = false;
        }
        //public EntidadCita() { }

        
        public EntidadCita()
        {
            id_cita = 0;
            fecha = DateTime.MinValue;//Convert.ToDateTime("25/06/2023");
            hora = TimeSpan.Zero;
            descripcion = string.Empty;
            id_medico = 0;
            id_pago = 0;
            id_paciente = 0;
            detalle_Medico = string.Empty;
            estado_Pago = false;
            existe= false;
        }
        

    }
}
