﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadHistorial_Medico
    {
        private int id_historial_medico;
        private int id_diagnostico;
        private int id_paciente;
        private DateTime fecha_creacion;
        private string descripcion;
        private bool existe;
        public int Id_historial_medico { get => id_historial_medico; set => id_historial_medico = value; }
        public int Id_diagnostico { get => id_diagnostico; set => id_diagnostico = value; }
        public int Id_paciente { get => id_paciente; set => id_paciente = value; }
        public DateTime Fecha_creacion { get => fecha_creacion; set => fecha_creacion = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public bool Existe { get => existe; set => existe = value; }

        public EntidadHistorial_Medico(int id_historial_medico, int id_diagnostico, int id_paciente, DateTime fecha_creacion, string descripcion, bool existe)
        {
            this.id_historial_medico = id_historial_medico;
            this.id_diagnostico = id_diagnostico;
            this.id_paciente = id_paciente;
            this.fecha_creacion = fecha_creacion;
            this.descripcion = descripcion;
            this.existe = existe;
        }
        public EntidadHistorial_Medico() {
            id_historial_medico = 0;
            id_diagnostico = 0;
            id_paciente = 0;
            fecha_creacion = DateTime.MinValue;
            descripcion = string.Empty;
            Existe = false;
        }

      
    }
}
