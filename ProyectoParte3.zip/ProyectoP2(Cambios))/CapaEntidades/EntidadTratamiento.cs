﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadTratamiento
    {
        private int id_tratamiento;
        private int id_medicamentos;
        private string descripcion;

        public int Id_tratamiento { get => id_tratamiento; set => id_tratamiento = value; }
        public int Id_medicamentos { get => id_medicamentos; set => id_medicamentos = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }

        public EntidadTratamiento(int id_tratamiento, int id_medicamentos, string descripcion)
        {
            this.id_tratamiento = id_tratamiento;
            this.id_medicamentos = id_medicamentos;
            this.descripcion = descripcion;
        }

        public EntidadTratamiento() { }
    }
}
