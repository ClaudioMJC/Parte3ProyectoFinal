﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadPago
    {
        private int id_pago;
        private double monto;
        private DateTime fecha_pago;

        public EntidadPago() 
        {
            id_pago = 0;
            monto = 0;
            fecha_pago = DateTime.MinValue;
        }

        public EntidadPago(int id_pago,double monto, DateTime fecha_pago) 
        { 
            this.id_pago = id_pago;
            this.monto = monto;
            this.fecha_pago=fecha_pago;
        }

        public int Id_pago { get => id_pago; set => id_pago = value; }
        public double Monto { get => monto; set => monto = value; }
        public DateTime Fecha_pago { get => fecha_pago; set => fecha_pago = value; }
    }
}
