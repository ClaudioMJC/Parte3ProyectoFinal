﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static CapaEntidades.EntidadUsuario;

namespace WebApp
{
    public partial class frmaddHorario : System.Web.UI.Page
    {
        string mensajeScript = "";
        EntidadHorario horarioRegistrado;
        protected void Page_Load(object sender, EventArgs e)
        {

            EntidadHorario horario;
            BLHorario logica = new BLHorario(clsConfiguracion.getConnectionString);
            int idHorario;

            try
            {
                if (!Page.IsPostBack)
                {
                    if (Session["id_del_Horario"] != null)
                    {
                        idHorario = int.Parse(Session["id_del_horario"].ToString());
                        horario = logica.ObtenerHorario(idHorario);
                        if (horario != null && horario.Existe)
                        {

                            txtIdHorario.Text = horario.Id_horario.ToString();
                            cboIdUsuarios.Text = horario.Id_usuario.ToString();
                            txtDiasTrabajados.Text = horario.DiasTrabajados;
                            txtHoraIN.Text = horario.HoraInicio.ToString();
                            txtHoraFIN.Text = horario.HoraFin.ToString();
                        }
                        else
                        {
                            mensajeScript = "javascript:mostrarMensaje('Horario no encontrado')";
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                    }
                    else
                    {
                        LimpiarCampos();
                        txtIdHorario.Text = "-1";
                    }
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("FrmPacientes.aspx");
            }

            BLHorario idNombre = new BLHorario(clsConfiguracion.getConnectionString);
            BLHorario idT = new BLHorario(clsConfiguracion.getConnectionString);

            try
            {
                List<UsuarioIdNO> nombreMasid = idNombre.ObtenerIdUsuarioyNombre();

                foreach (UsuarioIdNO idN in nombreMasid)
                {
                    cboTrabajadores.Items.Add(idN.ToString());
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('Error al cargar las especialidades')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }


            try
            {
                List<int> idlist = idT.ObtenerIdUsuarios();

                foreach (int idTr in idlist)
                {
                    cboIdUsuarios.Items.Add(idTr.ToString());
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('Error al cargar las especialidades')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }

        }


        public void LimpiarCampos()
        {
            txtIdHorario.Text = string.Empty;
            //txtIdUsuario.Text = string.Empty;
            txtDiasTrabajados.Text = string.Empty;
            txtHoraIN.Text = string.Empty;
            txtHoraFIN.Text = string.Empty;
            cboIdUsuarios.Items.Clear();
            txtDiasTrabajados.Focus();
        }


        private EntidadHorario GenerarEntidadHorario()
        {
            EntidadHorario horario = new EntidadHorario();
            if (Session["id_del_horario"] != null)
            {
                horario.Id_horario = int.Parse(Session["id_del_horario"].ToString());
                horario.Existe = true;
            }
            else
            {
                horario.Id_usuario = -1;
                horario.Existe = false;
            }

            //if (!string.IsNullOrEmpty(txtIdHorario.Text)) //si no es null o no está vacío se utiliza el objeto horario existente.
            //{
            //    horario = horarioRegistrado;
            //}
            //else
            //{
            //    horario = new EntidadHorario(); // si txtIdCliente está vacío, se crea un nuevo objeto horario y se asigna a la variable horario
            //}

            int idH;
            if (int.TryParse(txtIdHorario.Text, out idH))
            {
                horario.Id_horario = idH;
            }
            else
            {
                horario.Id_horario = 0;
                //MessageBox.Show("El valor del campo ID Cita no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }



            //EntidadHorario unHorario = new EntidadHorario();



            horario.DiasTrabajados = txtDiasTrabajados.Text; //cambiar

            //string diasTrabajados = "";

            //if (!String.IsNullOrEmpty(txtDiasTrabajados.Text))
            //{
            //    unHorario.DiasTrabajados = diasTrabajados;

            //}
            //else
            //{
            //    diasTrabajados = string.Empty;
            //}



            TimeSpan horaInicio;
            if (TimeSpan.TryParse(txtHoraIN.Text, out horaInicio))
            {
                horario.HoraInicio = horaInicio; //cambiar
            }
            else
            {
                horaInicio = TimeSpan.Zero;
            }

            TimeSpan horaFin;

            if (TimeSpan.TryParse(txtHoraFIN.Text, out horaFin))
            {
                horario.HoraFin = horaFin; //cambiar
            }
            else
            {
                horaFin = TimeSpan.Zero;
            }


            int idUsuario;
            if (int.TryParse(cboIdUsuarios.Text, out idUsuario))
            {
                horario.Id_usuario = idUsuario; //cambiar
            }
            else
            {
                mensajeScript = "javascript:mostrarMensaje('El valor del campo ID Usuario no es válido')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                
                
            }





            return horario; //cambiar


        }


        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHorario horario;
            BLHorario logica = new BLHorario(clsConfiguracion.getConnectionString);
            int resultado;

            try
            {
                horario = GenerarEntidadHorario();
                if (horario.Existe)
                {
                    resultado = logica.Modificar(horario);
                }
                else
                {
                    if (!string.IsNullOrEmpty(txtDiasTrabajados.Text) || !string.IsNullOrEmpty(txtHoraIN.Text) ||!string.IsNullOrEmpty(txtHoraFIN.Text) || !string.IsNullOrEmpty(cboIdUsuarios.Text))
                    {
                        resultado = logica.LlamarMetodoInsertar(horario);
                    }
                    else
                    {
                        mensajeScript = "javascript:mostrarMensaje('Debe agregar los datos requeridos del horario')";
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        resultado = -1;
                    }
                }

                if (resultado > 0)
                {
                    mensajeScript = "javascript:mostrarMensaje('Operación realizada satisfactoriamente')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    Response.Redirect("FrmHorarios.aspx");
                }
                else
                {
                    mensajeScript = "javascript:mostrarMensaje('No se puede ejecutar la operación')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmHorarios.aspx");
        }


    }
}