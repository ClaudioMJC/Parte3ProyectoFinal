﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp
{
    public partial class frmaddUsario : System.Web.UI.Page
    {
        string mensajeScript = "";
        EntidadUsuario usuarioRegistrado; 
        protected void Page_Load(object sender, EventArgs e)
        {
            EntidadUsuario usuario;
            BLUsuario logica = new BLUsuario(clsConfiguracion.getConnectionString);
            int idUsuario;

            try
            {
                if (!Page.IsPostBack)
                {
                    if (Session["id_del_usuario"] != null)
                    {
                        idUsuario = int.Parse(Session["id_del_usuario"].ToString());
                        usuario = logica.ObtenerUsuario(idUsuario);
                        if (usuario != null && usuario.Existe)
                        {
                            
                            txtIdUsuario.Text = usuario.Id_usuario.ToString();
                            txtNombreU.Text = usuario.NombreUsuario;
                            txtContrasena.Text = usuario.Clave;
                            cboRoles.Text = usuario.Id_rol.ToString();
                        }
                        else
                        {
                            mensajeScript = "javascript:mostrarMensaje('Paciente no encontrado')";
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                    }
                    else
                    {
                        LimpiarCampos();
                        txtIdUsuario.Text = "-1";
                    }
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("FrmPacientes.aspx");
            }


            // Agregar opciones al ComboBox
            cboNombreyIdRol.Items.Add("Busque el id de su Rol");
            cboNombreyIdRol.Items.Add("ID_ROL 1 Administrador");
            cboNombreyIdRol.Items.Add("ID_ROL 2 MEDICO ");
            cboNombreyIdRol.Items.Add("ID_ROL 3 ENFERMERO");
            cboNombreyIdRol.Items.Add("ID_ROL 4 ENFERMERO");
            // Establecer una opción seleccionada por defecto
            cboNombreyIdRol.SelectedIndex = 0;

            BLUsuario roles = new BLUsuario(clsConfiguracion.getConnectionString);

            // Obtener la lista de ID de roles desde la capa lógica
            List<int> idRoles = roles.ObtenerIdRoles();

            // Recorrer la lista de ID de roles y agregarlos al ComboBox
            foreach (int idRol in idRoles)
            {
                cboRoles.Items.Add(idRol.ToString());
            }


        }

        public void LimpiarCampos()
        {
            txtIdUsuario.Text = string.Empty;
            txtNombreU.Text = string.Empty;
            txtContrasena.Text = string.Empty;
            cboRoles.Text = string.Empty;

        }


        private EntidadUsuario GenerarEntidadUsuario()
        {
            EntidadUsuario usuario = new EntidadUsuario();

            if (Session["id_del_usuario"] != null)
            {
                usuario.Id_usuario = int.Parse(Session["id_del_usuario"].ToString());
                usuario.Existe = true;
            }
            else
            {
                usuario.Id_usuario = -1;
                usuario.Existe = false;
            }


            int idUsuario;
            if (int.TryParse(txtIdUsuario.Text, out idUsuario))
            {
                usuario.Id_usuario = idUsuario;     
            }
            else
            {
                usuario.Id_usuario = 0;         
                
            }


            //EntidadUsuario Unusuario = new EntidadUsuario();

            
            usuario.NombreUsuario = txtNombreU.Text;  //cambiar
            


            usuario.Clave = txtContrasena.Text;
            //string clave = txtContrasena.Text.Trim();
            //if (!string.IsNullOrEmpty(clave))
            //{
            //    usuario.Clave = clave;
            //}
            //else
            //{
            //    mensajeScript = "javascript:mostrarMensaje('Debe ingresar una contraseña válida')";
            //    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            //}



            int idRol;
            if (int.TryParse(cboRoles.Text, out idRol))
            {
                usuario.Id_rol = idRol;
            }
            else
            {
                mensajeScript = "javascript:mostrarMensaje('El valor del campo Id_Pago no es válido')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }


            //usuario.Id_rol = (int)cboRoles.SelectedValue;



            return usuario;
            //txtIdUsuario.Text = usuario.Id_usuario.ToString();
            //txtNombreU.Text = usuario.NombreUsuario;
            //txtContrasena.Text = usuario.Clave;
            //cboRoles.Text = usuario.Id_rol.ToString();
        }


        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadUsuario usuario;
            BLUsuario logica = new BLUsuario(clsConfiguracion.getConnectionString);
            int resultado;

            try
            {
                usuario = GenerarEntidadUsuario();
                if (usuario.Existe)
                {
                    resultado = logica.Modificar(usuario);
                }
                else
                {
                    if (!string.IsNullOrEmpty(txtNombreU.Text))
                    {
                        resultado = logica.LlamarMetodoInsertar(usuario);
                    }
                    else
                    {
                        mensajeScript = "javascript:mostrarMensaje('Debe agregar al menos el nombre del usuario')";
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        resultado = -1;
                    }
                }

                if (resultado > 0)
                {
                    mensajeScript = "javascript:mostrarMensaje('Operación realizada satisfactoriamente')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    Response.Redirect("FrmUsers.aspx");
                }
                else
                {
                    mensajeScript = "javascript:mostrarMensaje('No se puede ejecutar la operación')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("frmUsers.aspx");
        }



    }
}