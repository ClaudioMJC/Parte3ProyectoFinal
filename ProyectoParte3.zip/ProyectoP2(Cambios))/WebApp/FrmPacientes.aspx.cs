﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Capa02_LogicaNegocio;
using System.Data;
using CapaEntidades;

namespace WebApp
{
    public partial class FrmPacientes : System.Web.UI.Page
    {
        string mensajeScript = "";


        private void CargarListaDataSet(string condicion = "", string orden = "")
        {
            //carga el datagridview con el dataset
            BLPaciente logica = new BLPaciente(clsConfiguracion.getConnectionString);
            DataSet DSClientes;

            try
            {
                DSClientes = logica.ListarPacientes2(condicion, orden);
                grdPacientes.DataSource = DSClientes;
                grdPacientes.DataMember = DSClientes.Tables[0].TableName;
                grdPacientes.DataBind();

                //en la tabla con nombre Clientes del dataset
            }
            catch (Exception ex)
            {
                //throw
            }
        }// fin CargarListaDataSet

        //Muestra o carga el registro de pacientes para mostrarlos en la webapp
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    CargarListaDataSet();
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }

        }

        //permite la paginación app web (evita que la lista de registros excesivamente larga al cargarse
        protected void grdPacientes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdPacientes.PageIndex = e.NewPageIndex;
            CargarListaDataSet();
        }


        //Método de buscar app web
        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string condicion = string.Format("NOMBRE LIKE '%{0}%'", txtNombre.Text);
                CargarListaDataSet(condicion);
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }
        }


        //Elminar registro en la appweb//
        protected void InkEliminar_Command(object sender, CommandEventArgs e)
        {
            int id = int.Parse(e.CommandArgument.ToString());
            BLPaciente logica = new BLPaciente(clsConfiguracion.getConnectionString);
            EntidadPaciente paciente;
            try
            {
                paciente = logica.ObtenerPaciente(id);
                if (paciente.Existe)
                {
                    
                    if (logica.EliminarPaciente(paciente) > 0)
                    {
                        mensajeScript = string.Format("javascript:mostrarMensaje('Paciente Eliminado correctamente')");
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, false);
                        CargarListaDataSet();
                        txtNombre.Text = "";
                    }
                    else
                    {
                        mensajeScript = string.Format("javascript:mostrarMensaje('{0}'", logica.Mensaje);
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    }
                }

            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }



        }

        protected void IknModificar_Command(object sender, CommandEventArgs e)
        {
            Session["id_del_paciente"] = e.CommandArgument.ToString();
            Response.Redirect("addPaciente.aspx");
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            Session.Remove("id_del_paciente");
            Response.Redirect("addPaciente.aspx");
        }

        protected void btnReturnM_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu.aspx");
        }
    }
}