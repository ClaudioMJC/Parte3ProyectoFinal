﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApp
{
    public partial class frmaddCita : System.Web.UI.Page
    {
        string mensajeScript = "";
        EntidadCita citaRegistrada;
        protected void Page_Load(object sender, EventArgs e)
        {
            EntidadCita cita;
            BLCita2 logica = new BLCita2(clsConfiguracion.getConnectionString);
            int idCita;

            try
            {
                if (!Page.IsPostBack)
                {
                    if (Session["id_de_cita"] != null)
                    {
                        idCita = int.Parse(Session["id_de_cita"].ToString());
                        cita = logica.ObtenerCita(idCita);
                        if (cita != null && cita.Existe)
                        {
                            txtID_Cita.Text = cita.Id_cita.ToString();
                            cbo_ID_Pacientes.Text = cita.Id_paciente.ToString();
                            cboId_Medicos.Text = cita.Id_medico.ToString();
                            cbIDPagos.Text = cita.Id_pago.ToString();
                            dtCalendario.SelectedDate = cita.Fecha;
                            txtHoraCita.Text = cita.Hora.ToString();
                            cbEspecialidades.Text = cita.Detalle_Medico;
                            txtDescripcion.Text = cita.Descripcion;
                        }
                        else
                        {
                            mensajeScript = "javascript:mostrarMensaje('Paciente no encontrado')";
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                    }
                    else
                    {
                        LimpiarCampos2();
                        txtID_Cita.Text = "-1";
                    }
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("FrmPacientes.aspx");
            }


            BLCita2 blCita2 = new BLCita2(clsConfiguracion.getConnectionString);

            try
            {
                List<string> idsMedicos = blCita2.ObtenerIdMedicos();

                foreach (string idM in idsMedicos)
                {
                    cboId_Medicos.Items.Add(idM);
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('No se pudo realizar la operación')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
            //fin del primer combobox que carga el id de los médicos


            //ID_PACIENTE COMBOBOX

            try
            {
                List<string> idsPacientes = blCita2.ObtenerIdPacientes();

                foreach (string idPA in idsPacientes)
                {
                    cbo_ID_Pacientes.Items.Add(idPA);
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('No se pudo realizar la operación')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }

            ////ID_MEDICO, Nombre del doctor y su especialidad
            ///
            try
            {
                List<string> especialidades = blCita2.ObtenerMedicosPorEspecialidad();

                foreach (string especialidad in especialidades)
                {
                    cbEspecialidades.Items.Add(especialidad);
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('No se pudo realizar la operación')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }


            try
            {
                List<string> idPagos = blCita2.ObtenerIdPagos();

                foreach (string idPag in idPagos)
                {
                    cbIDPagos.Items.Add(idPag);
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('No se pudo realizar la operación')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }




        }

       

        public void LimpiarCampos2()
        {
            txtID_Cita.Text = string.Empty;
            cbo_ID_Pacientes.SelectedIndex = -1;
            cboId_Medicos.SelectedIndex = -1;
            cbIDPagos.SelectedIndex = -1;
            dtCalendario.TodaysDate = DateTime.Now;
            txtHoraCita.Text = string.Empty;
            cbEspecialidades.SelectedIndex = -1;
            txtDescripcion.Text = string.Empty;
            txtID_Cita.Focus();
        }


        private EntidadCita GenerarEntidadCita()
        {
            EntidadCita cita = new EntidadCita();
            if (Session["id_de_cita"] != null)
            {
                cita.Id_cita = int.Parse(Session["id_de_cita"].ToString());
                cita.Existe = true;
            }
            else
            {
                cita.Id_cita = -1;
                cita.Existe = false;
            }


            //EntidadCita unaCita = new EntidadCita();
           // se cometió un error que estaba provocando la duplicidad de registros cuando se modificaban
            //ya que se creaba un objeto "unaCita" que siempre devolvía un id en 0 como que no existía
            //aún en los casos en que si exstía el registro del paciente. El error fue no usar "cita"
            //el que había creado inicialmente

            int idCita;
            if (int.TryParse(txtID_Cita.Text, out idCita))
            {
                cita.Id_cita = idCita;     //cambiar
            }
            else
            {
                cita.Id_cita = 0;         //cambiar
                //MessageBox.Show("El valor del campo ID Cita no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }


            cita.Fecha = dtCalendario.SelectedDate.Date; //cambiar


            TimeSpan horaCita;
            if (TimeSpan.TryParse(txtHoraCita.Text, out horaCita))
            {
                cita.Hora = horaCita;     //cambiar
            }
            else
            {
                mensajeScript = "javascript:mostrarMensaje('El valor de la hora de la cita no es válido')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }


            cita.Descripcion = txtDescripcion.Text;    //cambiar

            int idMedico;
            if (int.TryParse(cboId_Medicos.Text, out idMedico))
            {
                cita.Id_medico = idMedico;          //cambiar
            }
            else
            {
                mensajeScript = "javascript:mostrarMensaje('El valor del campo ID_Médico no es válido')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }

            /*
            if (int.TryParse(cboId_Medicos.SelectedValue.ToString(), out idMedico))
            {
                unaCita.Id_medico = idMedico;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Médico no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }
            */
            int idPago;
            if (int.TryParse(cbIDPagos.Text, out idPago))
            {
                cita.Id_pago = idPago;    //cambiar
            }
            else
            {
                mensajeScript = "javascript:mostrarMensaje('El valor del campo ID_Pago no es válido')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }

            int idPaciente;
            if (int.TryParse(cbo_ID_Pacientes.Text, out idPaciente))
            {
                cita.Id_paciente = idPaciente;   //cambiar
            }
            else
            {
                mensajeScript = "javascript:mostrarMensaje('El valor del campo ID_Paciente no es válido')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
            /*
            string detalleMedico = string.Empty;
            foreach (var item in cbEspecialidades.Items)
            {
                detalleMedico += item.ToString() + " ";
            }
            unaCita.Detalle_Medico = detalleMedico.Trim();
            */
            if (cbEspecialidades.SelectedItem != null)     
            {
                cita.Detalle_Medico = cbEspecialidades.SelectedItem.ToString();  //cambiar
            }
            else
            {
                cita.Detalle_Medico = string.Empty;   //cambiar
            }



            return cita;  //cambiar




        }


        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadCita cita;
            BLCita2 logica = new BLCita2(clsConfiguracion.getConnectionString);
            int resultado;

            try
            {
                cita = GenerarEntidadCita();
                if (cita.Existe)
                {
                    resultado = logica.ModificarCita(cita);
                }
                else
                {
                    if (!string.IsNullOrEmpty(cbo_ID_Pacientes.Text) && !string.IsNullOrEmpty(cboId_Medicos.Text) && !string.IsNullOrEmpty(cbIDPagos.Text) && !string.IsNullOrEmpty(dtCalendario.ToString()) && !string.IsNullOrEmpty(txtHoraCita.Text) && !string.IsNullOrEmpty(cbEspecialidades.Text) && !string.IsNullOrEmpty(txtDescripcion.Text))
                    {
                        resultado = logica.LlamarMetodoInsertar(cita);
                    }
                    else
                    {
                        mensajeScript = "javascript:mostrarMensaje('Debe agregar los datos necesarios para registrar una cita')";
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        resultado = -1;
                    }
                }

                if (resultado > 0)
                {
                    mensajeScript = "javascript:mostrarMensaje('Operación realizada satisfactoriamente')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    Response.Redirect("FrmAgendarCita.aspx");
                }
                else
                {
                    mensajeScript = "javascript:mostrarMensaje('No se puede ejecutar la operación')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmAgendarCita.aspx");
        }



    }
}