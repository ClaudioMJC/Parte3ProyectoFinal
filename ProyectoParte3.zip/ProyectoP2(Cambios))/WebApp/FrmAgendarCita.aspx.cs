﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp
{
    public partial class FrmAgendarCita : System.Web.UI.Page
    {
        string mensajeScript = "";
        
        private void CargarListaDataSet(string condicion = "", string orden = "")
        {
            //carga el datagridview con el dataset
            BLCita2 logica = new BLCita2(clsConfiguracion.getConnectionString);
            DataSet DSCitas;

            try
            {
                DSCitas = logica.ListarCitas2(condicion, orden);
                grdCitas.DataSource = DSCitas;
                grdCitas.DataMember = DSCitas.Tables[0].TableName;
                grdCitas.DataBind();

                //en la tabla con nombre Clientes del dataset
            }
            catch (Exception ex)
            {
                //throw
            }
        }// fin CargarListaDataSet

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    CargarListaDataSet();
                    CargarListaDataSet2();
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }
        }

        protected void grdCitas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCitas.PageIndex = e.NewPageIndex;
            CargarListaDataSet();
        }

        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string condicion = string.Format("NOMBRE LIKE '%{0}%'", txtNombre.Text);
                CargarListaDataSet2(condicion);
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }
        }

        protected void BtnBuscar2_Click(object sender, EventArgs e)
        {
            try
            {
                string condicion = string.Format("ID_CITA LIKE '%{0}%'", txtCita.Text);
                CargarListaDataSet(condicion);
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }
        }


        //

        protected void InkEliminar_Command(object sender, CommandEventArgs e)
        {
            int id = int.Parse(e.CommandArgument.ToString());
            BLCita2 logica = new BLCita2(clsConfiguracion.getConnectionString);
            EntidadCita cita;
            try
            {
                cita = logica.ObtenerCita(id);
                if (cita.Existe)
                {

                    if (logica.EliminarCita(cita) > 0)
                    {
                        mensajeScript = string.Format("javascript:mostrarMensaje('Cita Eliminada correctamente')");
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, false);
                        CargarListaDataSet();
                        txtCita.Text = "";
                    }
                    else
                    {
                        mensajeScript = string.Format("javascript:mostrarMensaje('{0}'", logica.Mensaje);
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    }
                }

            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }



        }

        protected void IknModificar_Command(object sender, CommandEventArgs e)
        {
            Session["id_de_cita"] = e.CommandArgument.ToString();
            Response.Redirect("frmaddCita.aspx");
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            Session.Remove("id_de_cita");
            Response.Redirect("frmaddCita.aspx");
        }


        protected void btnReturnM_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu.aspx");
        }


        private void CargarListaDataSet2(string condicion = "", string orden = "")
        {
            //carga el datagridview con el dataset
            BLPaciente logica = new BLPaciente(clsConfiguracion.getConnectionString);
            DataSet DSClientes;

            try
            {
                DSClientes = logica.ListarPacientes2(condicion, orden);
                grdPacientes.DataSource = DSClientes;
                grdPacientes.DataMember = DSClientes.Tables[0].TableName;
                grdPacientes.DataBind();

                //en la tabla con nombre Clientes del dataset
            }
            catch (Exception ex)
            {
                //throw
            }
        }// fin CargarListaDataSet
        protected void grdPacientes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdPacientes.PageIndex = e.NewPageIndex;
            CargarListaDataSet2();
        }
        //Hasta aquí el código para buscar el paciente al cual se le va a registrar o agendar una cita
    }
}