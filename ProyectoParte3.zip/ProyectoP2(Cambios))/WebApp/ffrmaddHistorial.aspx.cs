﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp
{
    public partial class ffrmaddHistorial : System.Web.UI.Page
    {
        string mensajeScript = "";
        EntidadHistorial_Medico HistorialRegistrado;
        protected void Page_Load(object sender, EventArgs e)
        {
            EntidadHistorial_Medico historial;
            BLHistorial logica = new BLHistorial(clsConfiguracion.getConnectionString);
            int idHistorial;

            //try
            //{
            //    if (!Page.IsPostBack)
            //    {
            //        if (Session["id_del_historial"] != null)
            //        {
            //            idHistorial = int.Parse(Session["id_del_historial"].ToString());
            //            historial = logica.ObtenerHistorial(idHistorial);
            //            if (historial != null && historial.Existe)
            //            {
            //                /*
            //                txtIdHistorial.Text = historial.Id_historial_medico.ToString();
            //                historial.Id_paciente = int.Parse(cboIDPacientes.Text);
            //                historial.Fecha_creacion = DateTime.Parse(dtCalendario2.ToString());
            //                historial.Descripcion = txtDescripcion.Text;
            //                */

            //                historial.Id_historial_medico = int.Parse(txtIdHistorial.Text);
            //                historial.Id_paciente = int.Parse(cboIDPacientes.Text);
            //                historial.Fecha_creacion = dtCalendario2.SelectedDate;
            //                historial.Descripcion = txtDescripcion.Text;
            //            }
            //            else
            //            {
            //                mensajeScript = "javascript:mostrarMensaje('Historial no encontrado')";
            //                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            //            }
            //        }
            //        else
            //        {
            //            LimpiarCampos();
            //            txtIdHistorial.Text = "-1";
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
            //    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            //    Response.Redirect("FrmHistorialMedico.aspx");
            //}
            try
            {
                if (!Page.IsPostBack)
                {
                    if (Session["id_del_historial"] != null)
                    {
                        idHistorial = int.Parse(Session["id_del_historial"].ToString());
                        historial = logica.ObtenerHistorial(idHistorial);
                        if (historial != null && historial.Existe)
                        {
                            txtIdHistorial.Text = historial.Id_historial_medico.ToString();
                            historial.Id_paciente = int.TryParse(cboIDPacientes.Text, out int idPaciente) ? idPaciente : 0;
                            historial.Fecha_creacion = dtCalendario2.SelectedDate;
                            historial.Descripcion = txtDescripcion.Text;
                        }
                        else
                        {
                            mensajeScript = "javascript:mostrarMensaje('Historial no encontrado')";
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                    }
                    else
                    {
                        LimpiarCampos();
                        txtIdHistorial.Text = "-1";
                    }
                }
            }
            catch (FormatException ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('Error al convertir un valor: {0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('Error inesperado: {0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }


            BLHistorial paciente = new BLHistorial(clsConfiguracion.getConnectionString);  ////ID_PACIENTE, NOMBRE, APELLIDO
            ///
            try
            {
                List<string> infopacientes = paciente.ObtenerPacientesH();

                foreach (string informacionp in infopacientes)
                {
                    cbPacientesInfo.Items.Add(informacionp);
                }
            }
            catch (Exception)
            {
                mensajeScript = "javascript:mostrarMensaje('No se encontró registros')";
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }


            BLHistorial pacientesID = new BLHistorial(clsConfiguracion.getConnectionString);

            // Obtener la lista de ID de roles desde la capa lógica
            List<int> idPacientes = pacientesID.ObtenerIdPacientes();

            // Recorrer la lista de ID de roles y agregarlos al ComboBox
            foreach (int idP in idPacientes)
            {
                cboIDPacientes.Items.Add(idP.ToString());
            }


        }

        public void LimpiarCampos()
        {
            txtIdHistorial.Text = string.Empty;
            dtCalendario2.TodaysDate = DateTime.Now;
            txtDescripcion.Text = String.Empty;

        }



        private EntidadHistorial_Medico GenerarEntidadHistorial()
        {
            EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
            if (Session["id_del_historial"] != null)
            {
                historial.Id_historial_medico = int.Parse(Session["id_del_historial"].ToString());
                historial.Existe = true;
            }
            else
            {
                historial.Id_historial_medico = -1;
                historial.Existe = false;
            }

            historial.Id_historial_medico = int.Parse(txtIdHistorial.Text);
            historial.Id_paciente = int.Parse(cboIDPacientes.Text);
            historial.Fecha_creacion = dtCalendario2.SelectedDate;
            historial.Descripcion = txtDescripcion.Text;

            return historial;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHistorial_Medico historial;
            BLHistorial logica = new BLHistorial(clsConfiguracion.getConnectionString);
            int resultado;

            try
            {
                historial = GenerarEntidadHistorial();
                if (historial.Existe)
                {
                    resultado = logica.Modificar(historial);
                }
                else
                {
                    if (!string.IsNullOrEmpty(txtDescripcion.Text) && !string.IsNullOrEmpty(cboIDPacientes.Text))
                    {
                        resultado = logica.LlamarMetodoInsertar(historial);
                    }
                    else
                    {
                        mensajeScript = "javascript:mostrarMensaje('Debe agregar los datos de los campos del historial')";
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        resultado = -1;
                    }
                }

                if (resultado > 0)
                {
                    mensajeScript = "javascript:mostrarMensaje('Operación realizada satisfactoriamente')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    Response.Redirect("FrmHistorialMedico.aspx");
                }
                else
                {
                    mensajeScript = "javascript:mostrarMensaje('No se puede ejecutar la operación')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmHistorialMedico.aspx");
        }



    }
}