﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp
{
    public partial class Menu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRPacientes_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmPacientes.aspx");
           
        }

        protected void btnACita_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmAgendarCita.aspx");
        }

        protected void btnGUsuarios_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmUsers.aspx");
        }

        protected void btnHMedico_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmHistorialMedico.aspx");
        }

        protected void btnHTrabajadores_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmHorarios.aspx");
        }
    }
}