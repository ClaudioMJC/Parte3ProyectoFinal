﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp
{
    public partial class addPaciente : System.Web.UI.Page
    {
        string mensajeScript = "";

        public void Limpiar()
        {
            txtId.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtFechaNacimiento.Text = "";
            txtDireccion.Text = "";
            txtTelefono.Text = "";
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            EntidadPaciente paciente;
            BLPaciente logica = new BLPaciente(clsConfiguracion.getConnectionString);
            int idPaciente;

            try
            {
                if (!Page.IsPostBack)
                {
                    if (Session["id_del_paciente"] != null)
                    {
                        idPaciente = int.Parse(Session["id_del_paciente"].ToString());
                        paciente = logica.ObtenerPaciente(idPaciente);
                        if (paciente != null && paciente.Existe)
                        {
                            txtId.Text = paciente.Id_Paciente.ToString();
                            txtNombre.Text = paciente.Nombre;
                            txtApellido.Text = paciente.Apellido;
                            txtFechaNacimiento.Text = paciente.FechaNacimiento.ToString();
                            txtDireccion.Text = paciente.Direccion;
                            txtTelefono.Text = paciente.Telefono;
                        }
                        else
                        {
                            mensajeScript = "javascript:mostrarMensaje('Paciente no encontrado')";
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                    }
                    else
                    {
                        Limpiar();
                        txtId.Text = "-1";
                    }
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("FrmPacientes.aspx");
            }
        }

        private EntidadPaciente GenerarEntidadPaciente()
        {
            EntidadPaciente paciente = new EntidadPaciente();
            if (Session["id_del_paciente"] != null)
            {
                paciente.Id_Paciente = int.Parse(Session["id_del_paciente"].ToString());
                paciente.Existe = true;
            }
            else
            {
                paciente.Id_Paciente = -1;
                paciente.Existe = false;
            }
            paciente.Nombre = txtNombre.Text;
            paciente.Apellido = txtApellido.Text;
            paciente.FechaNacimiento = DateTime.TryParse(txtFechaNacimiento.Text, out var fechaValida) ? fechaValida : default(DateTime); 
            paciente.Direccion = txtDireccion.Text;
            paciente.Telefono = txtTelefono.Text;
            return paciente;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadPaciente paciente;
            BLPaciente logica = new BLPaciente(clsConfiguracion.getConnectionString);
            int resultado;

            try
            {
                paciente = GenerarEntidadPaciente();
                if (paciente.Existe)
                {
                    resultado = logica.Modificar(paciente);
                }
                else
                {
                    if (!string.IsNullOrEmpty(txtNombre.Text))
                    {
                        resultado = logica.LlamarMetodoInsertar(paciente);
                    }
                    else
                    {
                        mensajeScript = "javascript:mostrarMensaje('Debe agregar al menos el nombre del paciente')";
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        resultado = -1;
                    }
                }

                if (resultado > 0)
                {
                    mensajeScript = "javascript:mostrarMensaje('Operación realizada satisfactoriamente')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    Response.Redirect("FrmPacientes.aspx");
                }
                else
                {
                    mensajeScript = "javascript:mostrarMensaje('No se puede ejecutar la operación')";
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("frmPacientes.aspx");
        }




    }
}