﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp
{
    public partial class FrmUsers : System.Web.UI.Page
    {
        string mensajeScript = "";

        //
        private void CargarListaDataSet(string condicion = "", string orden = "")
        {
            //carga el datagridview con el dataset
            BLUsuario logica = new BLUsuario(clsConfiguracion.getConnectionString);
            DataSet DSUsuarios;

            try
            {
                DSUsuarios = logica.ListarUsuarios2(condicion, orden);
                grdUsuarios.DataSource = DSUsuarios;
                grdUsuarios.DataMember = DSUsuarios.Tables[0].TableName;
                grdUsuarios.DataBind();

                //en la tabla con nombre Clientes del dataset
            }
            catch (Exception ex)
            {
                //throw
            }
        }// fin CargarListaDataSet

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    CargarListaDataSet();
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }


        }


        //permite la paginación app web (evita que la lista de registros excesivamente larga al cargarse
        protected void grdUsuarios_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdUsuarios.PageIndex = e.NewPageIndex;
            CargarListaDataSet();
        }


        //Método de buscar app web
        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string condicion = string.Format("NOMBRE_USUARIO LIKE '%{0}%'", txtNombreU.Text);
                CargarListaDataSet(condicion);
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }
        }

        protected void InkEliminar_Command(object sender, CommandEventArgs e)
        {
            int id = int.Parse(e.CommandArgument.ToString());
            BLUsuario logica = new BLUsuario(clsConfiguracion.getConnectionString);
            EntidadUsuario usuario;
            try
            {
                usuario = logica.ObtenerUsuario(id);
                if (usuario.Existe)
                {

                    if (logica.EliminarUsuario(usuario) > 0)
                    {
                        mensajeScript = string.Format("javascript:mostrarMensaje('Usuario Eliminado correctamente')");
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, false);
                        CargarListaDataSet();
                        txtNombreU.Text = "";
                    }
                    else
                    {
                        mensajeScript = string.Format("javascript:mostrarMensaje('{0}'", logica.Mensaje);
                        ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    }
                }

            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                //throw;
            }



        }

        protected void IknModificar_Command(object sender, CommandEventArgs e)
        {
            Session["id_del_usuario"] = e.CommandArgument.ToString();
            Response.Redirect("frmaddUsario.aspx");
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            Session.Remove("id_del_usuario");
            Response.Redirect("frmaddUsario.aspx");
        }

        protected void btnReturnM_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu.aspx");
        }








    }
}