﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Capa03_AccesoDatos
{
    public class DAHistorial
    {
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DAHistorial(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }


        //Verificar la existencia de registros
        /*
        public bool ExisteHistorialMedico(int idHistorial)
        {
            bool existe = false;

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string consulta = "SELECT COUNT(*) FROM HISTORIAL_MEDICO WHERE ID_HISTORIAL_MEDICO = @ID_HISTORIAL_MEDICO";

                using (SqlCommand comando = new SqlCommand(consulta, conexion))
                {
                    comando.Parameters.AddWithValue("@ID_HISTORIAL_MEDICO", idHistorial);

                    try
                    {
                        conexion.Open();
                        int count = (int)comando.ExecuteScalar();
                        existe = (count > 0);
                    }
                    catch (Exception ex)
                    {
                        // Manejar la excepción según tus necesidades
                        throw new Exception("Error al verificar la existencia del historial médico", ex);
                    }
                }
            }

            return existe;
        }
        */
        /////////////////////////////////////////////////



        public List<int> ObtenerIdPaciente()
        {
            List<int> idPacientes = new List<int>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_PACIENTE FROM PACIENTE";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "PACIENTE");

                        foreach (DataRow fila in elDataSet.Tables["PACIENTE"].Rows)
                        {
                            int idRol = Convert.ToInt32(fila["ID_PACIENTE"]);
                            idPacientes.Add(idRol);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return idPacientes;
        }//FIN OBTENER EL ID_PACIENTES COMO PARTE DEL HISTORIAL_MEDICO



        public int Insertar(EntidadHistorial_Medico historial)
        {
            int id = 0;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO HISTORIAL_MEDICO (ID_PACIENTE, FECHA_CREACION,  DESCRIPCION) " +
                "VALUES (@ID_PACIENTE, @FECHA_CREACION, @DESCRIPCION) SELECT SCOPE_IDENTITY()";
            comando.Parameters.AddWithValue("@ID_PACIENTE", historial.Id_paciente);
            comando.Parameters.AddWithValue("@FECHA_CREACION", historial.Fecha_creacion);
            comando.Parameters.AddWithValue("@DESCRIPCION", historial.Descripcion);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }
        //////////////////////////////////////////////////////////////////////////////



        public List<EntidadHistorial_Medico> ListarHistoriales(string condicion = "")
        {
            List<EntidadHistorial_Medico> listaHistoriales = new List<EntidadHistorial_Medico>();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = "SELECT ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, FECHA_CREACION, DESCRIPCION FROM HISTORIAL_MEDICO";
            if (!string.IsNullOrEmpty(condicion))
            {
                sentencia = string.Format("{0} WHERE {1}", sentencia, condicion);
            }
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                while (dataReader.Read())
                {    /*
                    EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
                    historial.Id_historial_medico = dataReader.GetInt32(0);
                    historial.Id_diagnostico = dataReader.GetInt32(1);
                    historial.Id_paciente = dataReader.GetInt32(2);
                    historial.Fecha_creacion = dataReader.GetDateTime(3);
                    historial.Descripcion = dataReader.IsDBNull(4) ? string.Empty : dataReader.GetString(4);//en caso de que contenga valores nulos
                    listaHistoriales.Add(historial);
                    */
                    EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
                    historial.Id_historial_medico = dataReader.GetInt32(0);
                    historial.Id_diagnostico = dataReader["ID_DIAGNOSTICO"] != DBNull.Value ? dataReader.GetInt32(1) : 0;
                    historial.Id_paciente = dataReader["ID_PACIENTE"] != DBNull.Value ? dataReader.GetInt32(2) : 0;
                    //historial.Fecha_creacion = dataReader.GetDateTime(3);
                    historial.Fecha_creacion = dataReader["FECHA_CREACION"] != DBNull.Value ? dataReader.GetDateTime(3) : DateTime.MinValue;
                    historial.Descripcion = dataReader["DESCRIPCION"] != DBNull.Value ? dataReader.GetString(4) : string.Empty;
                    listaHistoriales.Add(historial);

                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return listaHistoriales;
        }


        //////////////////////////////////////////////////////////////////////////////


        public EntidadHistorial_Medico ObtenerHistorial(int id)
        {
            EntidadHistorial_Medico historial = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, FECHA_CREACION, DESCRIPCION FROM HISTORIAL_MEDICO WHERE ID_HISTORIAL_MEDICO = @ID_HISTORIAL_MEDICO");
            comando.Parameters.AddWithValue("@ID_HISTORIAL_MEDICO", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.Read())
                {
                    /*
                    historial = new EntidadHistorial_Medico();
                    historial.Id_historial_medico = dataReader.GetInt32(0);
                    historial.Id_diagnostico = dataReader.GetInt32(1);
                    historial.Id_paciente = dataReader.GetInt32(2);
                    historial.Fecha_creacion = dataReader.GetDateTime(3);
                    historial.Descripcion = dataReader.IsDBNull(4) ? string.Empty : dataReader.GetString(4);
                    */

                    
                    historial = new EntidadHistorial_Medico();
                    historial.Id_historial_medico = dataReader.GetInt32(0);
                    historial.Id_diagnostico = dataReader["ID_DIAGNOSTICO"] != DBNull.Value ? dataReader.GetInt32(1) : 0;
                    historial.Id_paciente = dataReader["ID_PACIENTE"] != DBNull.Value ? dataReader.GetInt32(2) : 0;
                    //historial.Fecha_creacion = dataReader.GetDateTime(3);
                    historial.Fecha_creacion = dataReader["FECHA_CREACION"] != DBNull.Value ? dataReader.GetDateTime(3) : DateTime.MinValue;
                    historial.Descripcion = dataReader["DESCRIPCION"] != DBNull.Value ? dataReader.GetString(4) : string.Empty;
                    historial.Existe = true;

                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return historial;
        }



        //////////////////////////////////////////////////////////////////////////////
        ///
        public int EliminarHistorialMedico(EntidadHistorial_Medico historial)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM HISTORIAL_MEDICO";
            sentencia = string.Format("{0} WHERE ID_HISTORIAL_MEDICO = {1}", sentencia, historial.Id_historial_medico);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }



        //////////////////////////////////////////////////////////////////////////////
        public int Modificar(EntidadHistorial_Medico historial)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE HISTORIAL_MEDICO SET ID_PACIENTE=@ID_PACIENTE, FECHA_CREACION=@FECHA_CREACION, DESCRIPCION=@DESCRIPCION WHERE ID_HISTORIAL_MEDICO=@ID_HISTORIAL_MEDICO";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_HISTORIAL_MEDICO", historial.Id_historial_medico);
            //comando.Parameters.AddWithValue("@ID_DIAGNOSTICO", historial.Id_diagnostico);
            comando.Parameters.AddWithValue("@ID_PACIENTE", historial.Id_paciente);
            comando.Parameters.AddWithValue("@FECHA_CREACION", historial.Fecha_creacion);
            comando.Parameters.AddWithValue("@DESCRIPCION", historial.Descripcion);
            try                //ID_DIAGNOSTICO=@ID_DIAGNOSTICO,
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;
        }




        //APP WEB

        //METODO PARA LA APLICACIÓN WEB(TERCERA PARTE DEL PROYECTO
        public DataSet ListarHistorial2(string condicion, string orden)
        {
            DataSet datos = new DataSet(); //Aqui se guardar la tabla de la consulta del sql
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            string sentencia = "SELECT ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, FECHA_CREACION, DESCRIPCION FROM HISTORIAL_MEDICO";

            if (!string.IsNullOrEmpty(condicion))
            { //si la condicion no esta vacia entonces concatene esa condicion a la sentencia
                sentencia = string.Format("{0} where {1}", sentencia, condicion);
            }

            if (!string.IsNullOrEmpty(orden))
            {//si orden no esta vacia entonces concatene ese orden a la sentencia
                sentencia = string.Format("{0} order by {1}", sentencia, orden);
            }
            try
            {
                adapter = new SqlDataAdapter(sentencia, conexion);
                //se realiza la conexion y se prepara el adaptador para ejecutar la sentencia
                adapter.Fill(datos, "Historiales");//el adaptador llena el dataset y le pone nombre 
            }
            catch (Exception)
            {
                throw;
            }
            return datos; //devuelve el dataset
        }//DataSet ListarClientes






        //prueba combobox extra

        //VISUALIZAR ID PACIENTE, NOMBRE Y APELLIDO


        public List<string> ObtenerPacientesH()
        {
            List<string> pacientes = new List<string>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = @"SELECT ID_PACIENTE, NOMBRE, APELLIDO FROM PACIENTE";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "PACIENTE");

                        foreach (DataRow fila in elDataSet.Tables["PACIENTE"].Rows)
                        {
                            string idPaciente = fila["ID_PACIENTE"].ToString();
                            string nombrePaciente = fila["NOMBRE"].ToString();
                            string apellidoPaciente = fila["APELLIDO"].ToString();

                            string datosPaciente = $"ID: {idPaciente}, Nombre: {nombrePaciente}, Apellido: {apellidoPaciente}";
                            pacientes.Add(datosPaciente);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return pacientes;
        }






    }






}

