﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Linq;
using static CapaEntidades.EntidadHorario;
using static CapaEntidades.EntidadUsuario;

namespace Capa03_AccesoDatos
{
    public class DAHorario
    {

        private string _cadenaConexion;
        private string _mensaje;

        public string Mensaje
        {
            get => _mensaje;
        }

        public DAHorario(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }


        

        public List<UsuarioIdNO> ObtenerIdUsuarioyNombre()
        {
            List<UsuarioIdNO> usuarios = new List<UsuarioIdNO>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_USUARIO, NOMBRE_USUARIO FROM USUARIO";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "USUARIO");

                        foreach (DataRow fila in elDataSet.Tables["USUARIO"].Rows)
                        {
                            int idUsuario = Convert.ToInt32(fila["ID_USUARIO"]);
                            string nombreUsuario = fila["NOMBRE_USUARIO"].ToString();

                            UsuarioIdNO usuario = new UsuarioIdNO()
                            {
                                Id_usuario = idUsuario,
                                NombreUsuario = nombreUsuario
                            };

                            usuarios.Add(usuario);
                            Console.WriteLine("ID_USUARIO: " + idUsuario + ", NOMBRE_USUARIO: " + nombreUsuario);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return usuarios;
        }




        public List<int> ObtenerIdUsuarios()
        {
            List<int> idUsuarios = new List<int>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_USUARIO FROM USUARIO";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "USUARIO");

                        foreach (DataRow fila in elDataSet.Tables["USUARIO"].Rows)
                        {
                            int idUsuario = Convert.ToInt32(fila["ID_USUARIO"]);
                            idUsuarios.Add(idUsuario);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return idUsuarios;
        }//combobox solo mostrar el ID_USUARIO





        public int Insertar(EntidadHorario horario)
        {
            int id = 0;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO Horario (ID_USUARIO, DIASTRABAJADOS, HORAINICIO, HORAFIN) " +
                "VALUES (@ID_USUARIO,@DIASTRABAJADOS, @HORAINICIO, @HORAFIN); SELECT SCOPE_IDENTITY();";
            comando.Parameters.AddWithValue("@ID_Usuario", horario.Id_usuario);
            comando.Parameters.AddWithValue("@DIASTRABAJADOS", horario.DiasTrabajados);
            comando.Parameters.AddWithValue("@HORAINICIO", horario.HoraInicio);
            comando.Parameters.AddWithValue("@HORAFIN", horario.HoraFin);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }

        public List<EntidadHorario> ListarHorarios(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<EntidadHorario> listaHorarios;

            string instruccionDB = "SELECT ID_HORARIO, ID_USUARIO, DIASTRABAJADOS, HORAINICIO, HORAFIN FROM Horario";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "HORARIO");
                listaHorarios = (from DataRow unaFila in elDataSet.Tables["HORARIO"].Rows
                                 select new EntidadHorario()
                                 {
                                     //unaFila["ID_CITA"] != DBNull.Value ? (int)unaFila["ID_CITA"] : 0,
                                     /*Id_horario = (int)unaFila[0],
                                     Id_usuario = (int)unaFila[1],
                                     DiasTrabajados = unaFila[2].ToString(),
                                     HoraInicio = TimeSpan.Parse(unaFila[3].ToString()),
                                     HoraFin = TimeSpan.Parse(unaFila[4].ToString())
                                     */
                                     Id_horario = unaFila["ID_Horario"] != DBNull.Value ? (int)unaFila["ID_Horario"] : 0,
                                     Id_usuario = unaFila["ID_Usuario"] != DBNull.Value ? (int)unaFila["ID_Usuario"] : 0,
                                     DiasTrabajados = unaFila["DIASTRABAJADOS"] != DBNull.Value ? unaFila["DIASTRABAJADOS"].ToString() : string.Empty,
                                     HoraInicio = unaFila["HORAINICIO"] != DBNull.Value ? TimeSpan.Parse(unaFila["HORAINICIO"].ToString()) : TimeSpan.Zero,
                                     HoraFin = unaFila["HORAFIN"] != DBNull.Value ? TimeSpan.Parse(unaFila["HORAFIN"].ToString()) : TimeSpan.Zero

                                 }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaHorarios;
        }

        public EntidadHorario ObtenerHorario(int id)
        {
            EntidadHorario horario = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_Horario, ID_Usuario, DIASTRABAJADOS, HORAINICIO, HORAFIN FROM Horario " +
                "WHERE ID_Horario = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    horario = new EntidadHorario();
                    dataReader.Read();
                    /*
                    horario.Id_horario = dataReader.GetInt32(0);
                    horario.Id_usuario = dataReader.GetInt32(1);
                    horario.DiasTrabajados = dataReader.GetString(2);
                    horario.HoraInicio = TimeSpan.Parse(dataReader[3].ToString());
                    horario.HoraFin = TimeSpan.Parse(dataReader[4].ToString());
                    */
                    horario.Id_horario = dataReader.GetInt32(0);
                    horario.Id_usuario = dataReader.IsDBNull(1) ? 0 : dataReader.GetInt32(1);
                    horario.DiasTrabajados = dataReader.IsDBNull(2) ? string.Empty : dataReader.GetString(2);
                    horario.HoraInicio = dataReader.IsDBNull(3) ? TimeSpan.Zero : TimeSpan.Parse(dataReader[3].ToString());
                    horario.HoraFin = dataReader.IsDBNull(4) ? TimeSpan.Zero : TimeSpan.Parse(dataReader[4].ToString());
                    horario.Existe = true;
                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return horario;
        }

        public int EliminarHorario(EntidadHorario horario)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM Horario";
            sentencia = string.Format("{0} WHERE ID_Horario = {1}", sentencia, horario.Id_horario);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }

        public int Modificar(EntidadHorario horario)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE Horario SET ID_Usuario=@ID_Usuario, DIASTRABAJADOS=@DIASTRABAJADOS, " +
                "HORAINICIO=@HORAINICIO, HORAFIN=@HORAFIN WHERE ID_Horario=@ID_Horario";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_Horario", horario.Id_horario);
            comando.Parameters.AddWithValue("@ID_Usuario", horario.Id_usuario);
            comando.Parameters.AddWithValue("@DIASTRABAJADOS", horario.DiasTrabajados);
            comando.Parameters.AddWithValue("@HORAINICIO", horario.HoraInicio);
            comando.Parameters.AddWithValue("@HORAFIN", horario.HoraFin);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;
        }





        //METODO PARA LA APLICACIÓN WEB(TERCERA PARTE DEL PROYECTO
        public DataSet ListarHorarios2(string condicion, string orden)
        {
            DataSet datos = new DataSet(); //Aqui se guardar la tabla de la consulta del sql
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            string sentencia = "SELECT ID_Horario, ID_Usuario, DIASTRABAJADOS, HORAINICIO, HORAFIN FROM Horario";

            if (!string.IsNullOrEmpty(condicion))
            { //si la condicion no esta vacia entonces concatene esa condicion a la sentencia
                sentencia = string.Format("{0} where {1}", sentencia, condicion);
            }

            if (!string.IsNullOrEmpty(orden))
            {//si orden no esta vacia entonces concatene ese orden a la sentencia
                sentencia = string.Format("{0} order by {1}", sentencia, orden);
            }
            try
            {
                adapter = new SqlDataAdapter(sentencia, conexion);
                //se realiza la conexion y se prepara el adaptador para ejecutar la sentencia
                adapter.Fill(datos, "Horarios");//el adaptador llena el dataset y le pone nombre 
            }
            catch (Exception)
            {
                throw;
            }
            return datos; //devuelve el dataset
        }//DataSet ListarClientes



    }
}
